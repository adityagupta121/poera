from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from signup.models import user
def signinfn(request):
    return  render(request,'signin/signin.html')


def login(request):
    usernamee=request.POST['UserName']
    passwordd=request.POST['Password']
    if user.objects.filter(username=usernamee,password=passwordd).exists():
                return render(request,'home/home.html')
    else:
        return HttpResponse('Passwords doesnt match')
# Create your views here.
