from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from signup.models import user


def profileefn(request):
    return render(request, 'profilee/profilee.html')




# Create your views here.
