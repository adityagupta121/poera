from django.apps import AppConfig


class ProfileeConfig(AppConfig):
    name = 'profilee'
