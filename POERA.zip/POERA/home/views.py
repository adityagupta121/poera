from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from signup.models import user
def homefn(request):
    return  render(request,'home/home.html')


# Create your views here.
