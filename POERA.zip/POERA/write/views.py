from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from signup.models import user


def writefn(request):
    return render(request, 'write/write.html')



# Create your views here.
