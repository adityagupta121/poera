from django.apps import AppConfig


class WriteConfig(AppConfig):
    name = 'write'
