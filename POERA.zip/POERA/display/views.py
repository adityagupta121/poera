from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from signup.models import user


def displayfn(request):
    return render(request, 'display/display.html')




# Create your views here.
