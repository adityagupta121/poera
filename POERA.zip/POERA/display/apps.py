from django.apps import AppConfig


class DisplayConfig(AppConfig):
    name = 'display'
