from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.
from signup.models import user


def signupfn(request):
    template=loader.get_template('signup/signup.html')
    context= {

    }
    return HttpResponse(template.render(context,request))


def add(request):
    usernamee=request.POST['UserName']
    passwordd=request.POST['Password']
    rpasswordd=request.POST['RePassword']
    if passwordd == rpasswordd:
        if user.objects.filter(username=usernamee).exists():
            return render(request, 'signup/signup.html',{"message":"Username already exists"})


        else:
            query = user(username=usernamee, password=passwordd)
            query.save()
            return render(request,'signin/signin.html')

    else:
        return render(request, 'signup/signup.html', {"message": "Passwords doesnt match"})

